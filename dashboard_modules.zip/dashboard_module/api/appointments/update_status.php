<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");

include_once '../config/database.php';

$data = json_decode(file_get_contents("php://input"));

if (!empty($data->appointment_id) && !empty($data->status)) {
    $id = (int)$data->appointment_id;
    $status = htmlspecialchars(strip_tags($data->status)); // upcoming, processing, done, cancelled

    $query = "UPDATE appointments SET status = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("si", $status, $id);

    if ($stmt->execute()) {
        echo json_encode(["status" => "success", "message" => "Appointment marked as " . $status]);
    } else {
        echo json_encode(["status" => "error", "message" => "Update failed."]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Invalid data."]);
}

$conn->close();
?>
