// DentAssist JS - Full Backend Integration
const app = {
    // Current logged-in user session
    currentUser: null,
    currentAppointments: [],
    globalQueueCache: [], // Cache for searching
    resetUserId: null,

    init: function () {
        this.setupAuthTabs();
        this.setupBookingSlots();
        this.setupOTPAuth();
        this.loadDentists(); // New: Load available dentists on startup
        console.log("DentAssist Initialized with PHP Backend!");

        setTimeout(() => {
            const splash = document.getElementById('splash-screen');
            if (splash) splash.classList.add('hide-splash');
        }, 500);
    },

    // --- Loading & Notifications ---
    showLoader: function (text = 'Processing...') {
        const loader = document.getElementById('global-loader');
        const loaderText = document.getElementById('loader-text');
        if (loaderText) loaderText.textContent = text;
        if (loader) loader.classList.remove('hidden');
    },

    hideLoader: function () {
        const loader = document.getElementById('global-loader');
        if (loader) loader.classList.add('hidden');
    },

    showToast: function (message, type = 'info') {
        const container = document.getElementById('toast-container');
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;

        const iconMap = {
            'success': 'bx-check-circle',
            'error': 'bx-error-circle',
            'info': 'bx-info-circle',
            'warning': 'bx-error'
        };

        toast.innerHTML = `
            <i class='bx ${iconMap[type] || 'bx-info-circle'} bx-sm'></i>
            <span>${message}</span>
        `;

        container.appendChild(toast);

        setTimeout(() => toast.classList.remove('hide'), 100);
        setTimeout(() => {
            toast.style.transform = 'translateX(120%)';
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    },

    // --- Authentication ---
    setupAuthTabs: function () {
        const tabs = document.querySelectorAll('.auth-tabs .tab-btn');
        tabs.forEach(tab => {
            tab.addEventListener('click', (e) => {
                tabs.forEach(t => t.classList.remove('active'));
                document.querySelectorAll('.auth-form').forEach(f => f.classList.remove('active'));

                e.target.classList.add('active');
                const targetId = `form-${e.target.dataset.target}`;
                document.getElementById(targetId).classList.add('active');
            });
        });
    },

    login: async function () {
        const emailInput = document.querySelector('#form-login input[type="text"]').value;
        const passwordInput = document.querySelector('#form-login input[type="password"]').value;

        if (!emailInput || !passwordInput) {
            this.showToast("Please enter email and password.", "warning");
            return;
        }

        this.showLoader('Authenticating...');

        try {
            const formData = { email: emailInput, password: passwordInput };
            const response = await fetch('api/auth/login.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(formData)
            });
            const result = await response.json();

            this.hideLoader();

            if (response.ok && result.status === 'success') {
                // Store user session
                this.currentUser = result.user;
                this.currentAppointments = result.appointments || [];

                const role = result.user.role;

                if (role === 'patient' || role === 'user') {
                    this.renderPatientDashboard();
                    this.switchScreen('patient-section');
                } else {
                    // Admin logic
                    const approvalMenu = document.getElementById('menu-approvals');
                    const dentistMenu = document.getElementById('menu-dentists');

                    if (result.user.is_master) {
                        if (approvalMenu) approvalMenu.classList.remove('hidden');
                        if (dentistMenu) dentistMenu.classList.remove('hidden');
                    } else {
                        if (approvalMenu) approvalMenu.classList.add('hidden');
                        if (dentistMenu) dentistMenu.classList.add('hidden');
                    }

                    this.renderAdminDashboard();
                    this.switchScreen('admin-section');
                }
                this.showToast(`Welcome back, ${result.user.name}!`, "success");
            } else {
                this.showToast(result.message || "Invalid credentials", "error");
            }
        } catch (error) {
            console.error("Login Error:", error);
            this.hideLoader();
            this.showToast("Failed to connect to backend server.", "error");
        }
    },

    register: async function () {
        const nameInput = document.getElementById('reg-name').value;
        const phoneInput = document.getElementById('reg-phone').value;
        const emailInput = document.getElementById('reg-email').value;
        const passwordInput = document.getElementById('reg-password').value;
        const roleRadio = document.querySelector('input[name="register-role"]:checked');

        if (!nameInput || !phoneInput || !emailInput || !passwordInput) {
            this.showToast("Please fill in all fields.", "warning");
            return;
        }

        this.showLoader("Creating secure account...");

        try {
            const formData = {
                full_name: nameInput,
                phone: phoneInput,
                email: emailInput,
                password: passwordInput,
                role: roleRadio ? roleRadio.value : 'patient'
            };

            const response = await fetch('api/auth/register.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(formData)
            });
            const result = await response.json();

            this.hideLoader();

            if (response.ok && result.status === 'success') {
                // If account is pending (Admins/Dentists), do NOT log in yet
                if (result.user.status === 'pending') {
                    this.hideLoader();
                    this.showToast("Account submitted for review.", "info");

                    // Show specialized 'Pending' view
                    document.getElementById('pending-name').textContent = result.user.name;
                    this.switchScreen('pending-section');
                    return;
                }

                // Normal login for patients
                this.currentUser = result.user;
                this.currentAppointments = [];

                this.showToast("Account created successfully!", "success");

                if (result.user.role === 'patient') {
                    this.switchScreen('onboarding-section');
                } else {
                    this.renderAdminDashboard();
                    this.switchScreen('admin-section');
                }
            } else {
                this.showToast(result.message || "Registration failed", "error");
            }
        } catch (error) {
            console.error("Register Error:", error);
            this.hideLoader();
            this.showToast("Failed to connect to backend server.", "error");
        }
    },

    // --- Forgot Password Flow ---
    verifyForReset: async function () {
        const email = document.getElementById('forgot-email').value;
        const phone = document.getElementById('forgot-phone').value;

        if (!email || !phone) {
            this.showToast("Please provide both email and phone.", "warning");
            return;
        }

        this.showLoader("Verifying account...");

        try {
            const response = await fetch('api/auth/verify_reset.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, phone })
            });
            const result = await response.json();

            this.hideLoader();

            if (result.status === 'success') {
                this.resetUserId = result.user_id;
                document.getElementById('forgot-step-1').classList.add('hidden');
                document.getElementById('forgot-step-2').classList.remove('hidden');
                this.showToast("Account verified! Enter your new password.", "success");
            } else {
                this.showToast(result.message || "Verification failed.", "error");
            }
        } catch (error) {
            console.error("Verify Error:", error);
            this.hideLoader();
            this.showToast("Error connecting to server.", "error");
        }
    },

    resetPassword: async function () {
        const newPass = document.getElementById('new-password').value;
        const confirmPass = document.getElementById('confirm-new-password').value;

        if (!newPass || newPass.length < 4) {
            this.showToast("Password must be at least 4 characters.", "warning");
            return;
        }

        if (newPass !== confirmPass) {
            this.showToast("Passwords do not match.", "error");
            return;
        }

        this.showLoader("Updating password...");

        try {
            const response = await fetch('api/auth/reset_password.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    user_id: this.resetUserId,
                    new_password: newPass
                })
            });
            const result = await response.json();

            this.hideLoader();

            if (result.status === 'success') {
                this.showToast(result.message, "success");
                setTimeout(() => {
                    // Reset UI
                    document.getElementById('forgot-step-1').classList.remove('hidden');
                    document.getElementById('forgot-step-2').classList.add('hidden');
                    document.getElementById('forgot-email').value = '';
                    document.getElementById('forgot-phone').value = '';
                    document.getElementById('new-password').value = '';
                    document.getElementById('confirm-new-password').value = '';
                    this.switchScreen('auth-section');
                }, 2000);
            } else {
                this.showToast(result.message || "Update failed.", "error");
            }
        } catch (error) {
            console.error("Reset Error:", error);
            this.hideLoader();
            this.showToast("Error connecting to server.", "error");
        }
    },

    submitOnboarding: async function () {
        if (!this.currentUser) {
            this.showToast("Session expired. Please login again.", "error");
            this.switchScreen('auth-section');
            return;
        }

        const form = document.getElementById('form-onboarding');
        const dob = form.querySelector('input[type="date"]').value;
        const emergName = form.querySelectorAll('input[type="text"]')[0].value;
        const emergPhone = form.querySelector('input[type="tel"]').value;
        const textareas = form.querySelectorAll('textarea');
        const allergies = textareas[0] ? textareas[0].value : '';
        const medications = textareas[1] ? textareas[1].value : '';

        this.showLoader("Saving medical history...");

        try {
            const payload = {
                user_id: this.currentUser.id,
                dob: dob,
                emergency_contact_name: emergName,
                emergency_contact_phone: emergPhone,
                allergies: allergies,
                medications: medications
            };

            const response = await fetch('api/patients/onboarding.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });
            const result = await response.json();

            this.hideLoader();

            if (response.ok && result.status === 'success') {
                // Update local session with new meta
                this.currentUser.dob = dob;
                this.currentUser.emergency_contact_name = emergName;
                this.currentUser.emergency_contact_phone = emergPhone;
                this.currentUser.allergies = allergies;
                this.currentUser.medications = medications;

                this.renderPatientDashboard();
                this.switchScreen('patient-section');
                this.showToast("Welcome to DentAssist Dashboard!", "success");
            } else {
                this.showToast(result.message || "Failed to save.", "error");
            }
        } catch (error) {
            console.error("Onboarding Error:", error);
            this.hideLoader();
            this.showToast("Failed to connect to backend server.", "error");
        }
    },

    // ===================================================================
    // RENDER PATIENT DASHBOARD — Dynamic from currentUser + appointments
    // ===================================================================
    renderPatientDashboard: function () {
        const user = this.currentUser;
        if (!user) return;

        // Ensure we have a valid name to work with
        const displayName = user.name || user.full_name || "Valued Patient";

        // --- Update nav bar name & initials ---
        const nameEl = document.getElementById('patient-nav-name');
        if (nameEl) nameEl.textContent = displayName;

        const avatarEl = document.getElementById('patient-avatar');
        if (avatarEl) {
            const initials = displayName.split(' ').filter(n => n).map(w => w[0]).join('').toUpperCase().substring(0, 2);
            avatarEl.textContent = initials || "??";
        }

        // --- Update dashboard greeting ---
        const greetingEl = document.getElementById('patient-greeting');
        if (greetingEl) {
            const firstName = displayName.split(' ')[0];
            greetingEl.textContent = `Hello, ${firstName}! 👋`;
        }

        // --- Update reward points ---
        const pointsEl = document.getElementById('patient-reward-points');
        if (pointsEl) {
            const pts = user.reward_points || 0;
            pointsEl.innerHTML = `<i class='bx bx-star text-lg mr-1'></i> ${pts} Reward Points`;
        }

        // --- Update Personal Information Dashboard Card ---
        const emailEl = document.getElementById('patient-info-email');
        if (emailEl) emailEl.textContent = user.email || "No email provided";

        const phoneEl = document.getElementById('patient-info-phone');
        if (phoneEl) phoneEl.textContent = user.phone || "No phone provided";

        const dobEl = document.getElementById('patient-info-dob');
        if (dobEl) dobEl.textContent = user.dob || 'Pending Onboarding';

        const joinedEl = document.getElementById('patient-info-joined');
        if (joinedEl) {
            const joinedDate = new Date(user.created_at || new Date());
            joinedEl.textContent = joinedDate.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
        }

        // --- Render upcoming appointment card or empty state ---
        const upcomingCard = document.getElementById('upcoming-appointment-card');

        // Sort upcoming: soonest first
        const upcoming = this.currentAppointments
            .filter(a => a.status === 'upcoming')
            .sort((a, b) => new Date(a.appointment_date + ' ' + a.start_time) - new Date(b.appointment_date + ' ' + b.start_time));

        // Sort past: newest first
        const past = this.currentAppointments
            .filter(a => a.status === 'completed' || a.status === 'cancelled')
            .sort((a, b) => new Date(b.appointment_date + ' ' + b.start_time) - new Date(a.appointment_date + ' ' + a.start_time));

        if (upcomingCard) {
            if (upcoming.length > 0) {
                const apt = upcoming[0];
                const date = new Date(apt.appointment_date);
                const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
                const day = date.getDate();
                const month = monthNames[date.getMonth()];
                const startFmt = this.formatTime(apt.start_time);
                const endFmt = this.formatTime(apt.end_time);

                upcomingCard.innerHTML = `
                    <div class="flex-center-between border-bottom pb-1 mb-1">
                        <h3 class="card-title mb-0 border-none pb-0"><i class='bx bx-calendar-check text-success mr-1'></i> Next Upcoming Visit</h3>
                        <span class="badge border-badge badge-active"><span class="dot blink bg-success"></span> Confirmed</span>
                    </div>
                    <div class="flex items-center gap-2 mt-2">
                        <div class="avatar-large flex-col flex-center bg-muted text-dim border-dashed">
                            <h2 class="m-0 text-xl font-bold">${day}</h2>
                            <span class="text-xs uppercase font-bold text-center">${month}</span>
                        </div>
                        <div class="flex-1">
                            <h3 class="font-bold text-lg">${apt.service_name}</h3>
                            <p class="text-dim text-sm mt-1 flex items-center gap-1"><i class='bx bx-time'></i> ${startFmt} - ${endFmt}</p>
                            <p class="text-dim text-sm flex items-center gap-1"><i class='bx bx-user-pin'></i> ${apt.dentist_name || 'Assigned Dentist'}</p>
                        </div>
                        <div class="btn-primary shadow-hover w-auto" onclick="app.switchPatientTab('my-appointments')"><i class='bx bx-calendar-edit mr-1'></i> Manage</div>
                    </div>
                `;
                upcomingCard.classList.remove('hidden');
            } else {
                upcomingCard.innerHTML = `
                    <div class="text-center py-2">
                        <div class="avatar-large mx-auto flex-center bg-muted text-dim border-dashed mb-1"><i class='bx bx-calendar-x text-xl'></i></div>
                        <h3 class="font-bold mt-1">No Upcoming Appointments</h3>
                        <p class="text-dim text-sm mt-1">You haven't booked any visits yet. Schedule one now!</p>
                        <button class="btn-primary mt-2 shadow-hover w-auto" onclick="app.switchPatientTab('booking')"><i class='bx bx-calendar-plus mr-1'></i> Book Your First Visit</button>
                    </div>
                `;
                upcomingCard.classList.remove('hidden');
            }
        }

        // --- Render My Records & Appointments tab ---
        const apptListEl = document.getElementById('appointments-list-dynamic');
        if (apptListEl) {
            let html = '';

            // Upcoming section
            html += `<h4 class="font-bold text-dim uppercase text-xs tracking-wide mb-1 flex items-center"><i class='bx bx-calendar mr-1'></i> Upcoming</h4>`;
            if (upcoming.length > 0) {
                upcoming.forEach(apt => {
                    const date = new Date(apt.appointment_date);
                    const monthNames = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
                    html += `
                    <div class="card appointment-card list-row hover-lift bg-white shadow-sm border-l-success">
                        <div class="apt-date text-center pattern-bg flex-col flex-center">
                            <span class="month text-xs font-bold text-dim">${monthNames[date.getMonth()]}</span>
                            <span class="day text-xl font-bold">${date.getDate()}</span>
                        </div>
                        <div class="apt-info flex-1">
                            <h4 class="font-bold text-lg mb-1">${apt.service_name}</h4>
                            <div class="flex items-center gap-2 text-sm text-dim">
                                <span class="info-badge bg-muted"><i class='bx bx-time'></i> ${this.formatTime(apt.start_time)} - ${this.formatTime(apt.end_time)}</span>
                                <span class="info-badge bg-muted"><i class='bx bx-user-pin'></i> ${apt.dentist_name || 'TBD'}</span>
                            </div>
                        </div>
                        <div class="apt-status">
                            <span class="badge border-badge badge-active"><span class="dot blink bg-success"></span> Confirmed</span>
                        </div>
                        <div class="apt-actions">
                            <button class="btn-icon circle outline" title="Reschedule" onclick="app.switchPatientTab('booking')"><i class='bx bx-calendar-edit'></i></button>
                            <button class="btn-icon circle outline text-danger ml-1" title="Cancel Appointment" onclick="app.cancelAppointment(${apt.id})"><i class='bx bx-trash'></i></button>
                        </div>
                    </div>`;
                });
            } else {
                html += `
                <div class="card text-center py-2 bg-muted border-dashed">
                    <p class="text-dim text-sm"><i class='bx bx-info-circle mr-1'></i> No upcoming appointments. <a href="#" class="font-bold" onclick="app.switchPatientTab('booking')">Book one now!</a></p>
                </div>`;
            }

            // Past section
            html += `<h4 class="font-bold text-dim uppercase text-xs tracking-wide mt-2 mb-1 flex items-center"><i class='bx bx-history mr-1'></i> Past Visits</h4>`;
            if (past.length > 0) {
                past.forEach(apt => {
                    const date = new Date(apt.appointment_date);
                    const monthNames = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
                    html += `
                    <div class="card appointment-card list-row hover-lift bg-muted border-none opacity-70">
                        <div class="apt-date text-center bg-white border-dashed flex-col flex-center">
                            <span class="month text-xs font-bold text-dim">${monthNames[date.getMonth()]}</span>
                            <span class="day text-lg font-bold">${date.getDate()}</span>
                        </div>
                        <div class="apt-info flex-1">
                            <h4 class="font-bold text-md mb-1 text-dim">${apt.service_name}</h4>
                            <div class="flex items-center gap-2 text-sm text-dim">
                                <span class="info-badge bg-white"><i class='bx bx-time'></i> ${this.formatTime(apt.start_time)}</span>
                                <span class="info-badge bg-white"><i class='bx bx-user-pin'></i> ${apt.dentist_name || 'TBD'}</span>
                            </div>
                        </div>
                        <div class="apt-status">
                            <span class="badge bg-white text-dim border-dashed"><i class='bx bx-check-double'></i> ${apt.status === 'completed' ? 'Completed' : 'Cancelled'}</span>
                        </div>
                    </div>`;
                });
            } else {
                html += `
                <div class="card text-center py-2 bg-muted border-dashed">
                    <p class="text-dim text-sm"><i class='bx bx-info-circle mr-1'></i> No past visits yet.</p>
                </div>`;
            }

            apptListEl.innerHTML = html;
        }

        // --- Render Treatment History tab ---
        const historyBody = document.getElementById('treatment-history-body');
        if (historyBody) {
            if (past.length > 0) {
                let rows = '';
                past.forEach(apt => {
                    const date = new Date(apt.appointment_date);
                    const options = { year: 'numeric', month: 'short', day: 'numeric' };
                    rows += `
                    <tr class="table-row-hover">
                        <td class="pl-2 font-medium">${date.toLocaleDateString('en-US', options)}</td>
                        <td><span class="info-badge">${apt.service_name}</span></td>
                        <td class="font-bold">N/A</td>
                        <td>${apt.dentist_name || 'TBD'}</td>
                        <td class="text-right pr-2"><button class="btn-icon circle outline sm bg-white inline-flex" title="View Clinical Notes" onclick="app.showToast('No clinical notes available yet.', 'info')"><i class='bx bx-file'></i></button></td>
                    </tr>`;
                });
                historyBody.innerHTML = rows;
            } else {
                historyBody.innerHTML = `
                <tr>
                    <td colspan="5" class="text-center py-2 text-dim">
                        <i class='bx bx-info-circle mr-1'></i> No treatment history yet. Your records will appear here after your first visit.
                    </td>
                </tr>`;
            }
        }

        // --- Update Recommended Services based on user history ---
        const recommendedEl = document.getElementById('recommended-service-list');
        if (recommendedEl) {
            if (past.length === 0) {
                // New user - recommend consultation
                recommendedEl.innerHTML = `
                    <div class="list-row items-center border-bottom pb-1 pt-1 mb-0 hover-lift bg-transparent pattern-bg-subtle"
                        style="cursor: pointer;" onclick="app.switchPatientTab('booking')">
                        <div class="avatar bg-primary-light text-primary flex-center border-dashed"><i class='bx bx-plus'></i></div>
                        <div class="flex-1">
                            <h4 class="font-bold">Initial Dental Consultation</h4>
                            <p class="text-sm text-dim">Complete your first checkup assessment today.</p>
                        </div>
                        <button class="btn-outline w-auto shadow-hover" onclick="app.switchPatientTab('booking')">
                            <i class='bx bx-calendar-plus mr-1'></i> Book Now</button>
                    </div>`;
            } else {
                // Return to default or another specific one
                recommendedEl.innerHTML = `
                    <div class="list-row items-center border-bottom pb-1 pt-1 mb-0 hover-lift bg-transparent pattern-bg-subtle"
                        style="cursor: pointer;" onclick="app.switchPatientTab('booking')">
                        <div class="avatar bg-muted text-dim flex-center border-dashed"><i class='bx bx-smile'></i></div>
                        <div class="flex-1">
                            <h4 class="font-bold">Laser Teeth Whitening</h4>
                            <p class="text-sm text-dim">Special 15% discount for returning patients.</p>
                        </div>
                        <button class="btn-outline w-auto shadow-hover" onclick="app.switchPatientTab('booking')">
                            <i class='bx bx-calendar-plus mr-1'></i> Book Now</button>
                    </div>`;
            }
        }
    },

    // ===================================================================
    // RENDER ADMIN DASHBOARD — Dynamic from currentUser
    // ===================================================================
    renderAdminDashboard: async function () {
        const user = this.currentUser;
        if (!user) return;

        // Update sidebar admin name & avatar
        const adminName = document.getElementById('admin-sidebar-name');
        if (adminName) adminName.textContent = user.name;

        const adminRole = document.getElementById('admin-sidebar-role');
        if (adminRole) adminRole.textContent = user.role === 'admin' ? 'Administrator' : 'Staff';

        const adminAvatar = document.getElementById('admin-avatar-sidebar');
        if (adminAvatar) {
            const initials = user.name.split(' ').map(w => w[0]).join('').toUpperCase().substring(0, 2);
            adminAvatar.textContent = initials;
        }

        // Update Admin Dashboard Header Date
        const dateBadge = document.getElementById('admin-date-badge');
        if (dateBadge) {
            const now = new Date();
            const dateStr = now.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
            dateBadge.innerHTML = `<i class='bx bx-calendar mr-1 text-dim'></i> ${dateStr}`;
        }

        // Fetch appointments from backend for admin view
        try {
            // Isolation Rule: Only fetch current dentist's data if NOT Master Admin
            const dentistFilter = !user.is_master ? `?dentist_id=${user.id}` : '';
            const response = await fetch(`api/appointments/get.php${dentistFilter}`);
            const result = await response.json();

            if (response.ok && result.status === 'success') {
                const allAppts = result.data;

                // Update stats
                const todayStr = new Date().toISOString().split('T')[0];
                const todayAppts = allAppts.filter(a => a.appointment_date === todayStr);
                const walkIns = allAppts.filter(a => a.status === 'walk-in');
                const totalRevenue = allAppts.reduce((acc, curr) => acc + (parseFloat(curr.price) || 0), 0);

                const todayEl = document.getElementById('admin-stat-today');
                if (todayEl) todayEl.textContent = todayAppts.length;

                const walkinsEl = document.getElementById('admin-stat-walkins');
                if (walkinsEl) walkinsEl.textContent = walkIns.length;

                const revenueEl = document.getElementById('admin-stat-revenue');
                if (revenueEl) revenueEl.textContent = `$${totalRevenue.toLocaleString()}`;

                // Update upcoming schedule table
                const scheduleBody = document.getElementById('admin-schedule-body');
                if (scheduleBody) {
                    scheduleBody.innerHTML = ''; // Clear previous
                    if (allAppts.length > 0) {
                        let rows = '';
                        allAppts.slice(0, 10).forEach(apt => {
                            const pName = apt.patient_name || 'Quick Booking';
                            const initials = pName.split(' ').map(n => n[0]).join('').toUpperCase().substring(0, 2);
                            const aptDate = new Date(apt.appointment_date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });

                            const statusClass = apt.status === 'pending' ? 'bg-warning-light text-warning' :
                                (apt.status === 'upcoming' ? 'bg-success-light text-success' : 'badge-upcoming');

                            let actionsHtml = `<button class="btn-icon circle outline sm mr-1" onclick="app.viewPatientDetails(${apt.patient_id})" title="View Patient Profile"><i class='bx bx-show'></i></button>`;

                            if (apt.status === 'pending') {
                                actionsHtml += `
                                    <button class="btn-icon circle bg-success-light text-success sm mr-1" onclick="app.updateAppointmentStatus(${apt.id}, 'upcoming')" title="Approve Request">
                                        <i class='bx bx-check'></i>
                                    </button>
                                    <button class="btn-icon circle bg-muted text-danger sm" onclick="app.updateAppointmentStatus(${apt.id}, 'cancelled')" title="Decline Request">
                                        <i class='bx bx-x'></i>
                                    </button>
                                `;
                            } else {
                                actionsHtml += `
                                    <button class="btn-icon circle outline text-danger sm" onclick="app.cancelAppointment(${apt.id})" title="Cancel Appointment">
                                        <i class='bx bx-trash'></i>
                                    </button>
                                `;
                            }

                            rows += `
                            <tr class="table-row-hover">
                                <td class="text-dim text-xs">${aptDate}</td>
                                <td class="font-bold">${this.formatTime(apt.start_time)}</td>
                                <td>
                                    <div class="flex items-center gap-1">
                                        <div class="avatar-tiny bg-primary-light text-dim">${initials}</div>
                                        <span class="font-medium text-sm">${pName}</span>
                                    </div>
                                </td>
                                <td><span class="info-badge">${apt.service_name}</span></td>
                                <td><span class="badge ${statusClass} uppercase text-xs">${apt.status}</span></td>
                                <td class="text-right">${actionsHtml}</td>
                            </tr>`;
                        });
                        scheduleBody.innerHTML = rows;
                    } else {
                        scheduleBody.innerHTML = `
                        <tr>
                            <td colspan="6" class="text-center py-3 text-dim bg-muted border-dashed rounded-lg">
                                <div class="py-2">
                                    <i class='bx bx-calendar-x text-2xl mb-1 opacity-50'></i>
                                    <p class="font-bold">No Bookings Found</p>
                                    <p class="text-xs">Patient appointments will appear here.</p>
                                </div>
                            </td>
                        </tr>`;
                    }
                }
            }
        } catch (err) {
            console.error("Critical error fetching admin data:", err);
            const scheduleBody = document.getElementById('admin-schedule-body');
            if (scheduleBody) scheduleBody.innerHTML = '<tr><td colspan="6" class="text-center text-error py-2">Failed to load live data. Check database connection.</td></tr>';
        }
    },

    // --- Helper: Format time from 24h to 12h ---
    formatTime: function (timeStr) {
        if (!timeStr) return '';
        const parts = timeStr.split(':');
        let h = parseInt(parts[0]);
        const m = parts[1];
        const ampm = h >= 12 ? 'PM' : 'AM';
        h = h % 12 || 12;
        return `${h}:${m} ${ampm}`;
    },

    logout: function () {
        this.currentUser = null;
        this.currentAppointments = [];
        this.switchScreen('auth-section');
        this.showToast("Logged out successfully.", "info");
    },

    // --- Screen Navigation ---
    switchScreen: function (screenId) {
        document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
        document.getElementById(screenId).classList.add('active');

        const chatToggle = document.getElementById('chat-toggle');
        const chatUI = document.getElementById('chatbot-ui');
        if (['auth-section', 'onboarding-section', 'forgot-password-section', 'phone-login-section', 'google-account-section', 'phone-otp-section'].includes(screenId)) {
            if (chatToggle) chatToggle.classList.add('hidden');
            if (chatUI) chatUI.classList.add('hidden');
        } else {
            if (chatToggle) chatToggle.classList.remove('hidden');
        }

        if (screenId === 'phone-otp-section') {
            const otpInputs = document.querySelectorAll('.otp-input');
            otpInputs.forEach(i => i.value = '');
            setTimeout(() => { if (otpInputs[0]) otpInputs[0].focus(); }, 100);
        }
    },

    // --- Patient Flow ---
    switchPatientTab: function (tabId) {
        document.querySelectorAll('.patient-tab').forEach(t => t.classList.remove('active'));
        document.getElementById(`patient-${tabId}`).classList.add('active');

        document.querySelectorAll('.nav-links a').forEach(a => a.classList.remove('active'));
        if (event && event.target) event.target.classList.add('active');
    },

    checkAvailability: async function () {
        const dentistId = document.getElementById('selected-dentist-id').value;
        const dateInput = document.getElementById('booking-date').value;

        if (!dentistId) {
            this.showToast("Please choose a dentist in Step 1.", "warning");
            return;
        }
        if (!dateInput) {
            this.showToast("Please select a date.", "warning");
            return;
        }

        const slotsCard = document.getElementById('time-slots');
        const slotsContainer = document.getElementById('slots-container');

        this.showLoader("Scanning availability...");

        try {
            const response = await fetch(`api/appointments/get_available_slots.php?dentist_id=${dentistId}&date=${dateInput}`);
            const result = await response.json();
            this.hideLoader();

            if (result.status === 'success') {
                if (result.slots.length > 0) {
                    let html = '';
                    result.slots.forEach(slot => {
                        html += `<button class="slot-btn" onclick="app.selectSlot(this)">${slot}</button>`;
                    });
                    slotsContainer.innerHTML = html;
                    slotsCard.style.opacity = '1';
                    slotsCard.style.pointerEvents = 'auto';
                    this.showToast("Real-time slots updated!", "success");
                } else {
                    slotsContainer.innerHTML = '<div class="text-center w-full py-2 text-error text-xs">No available slots for this day.</div>';
                    this.showToast("Oops! Dentist is fully booked for this day.", "info");
                }
            }
        } catch (e) {
            this.hideLoader();
            this.showToast("Connection error checking slots.", "error");
        }
    },

    selectSlot: function (btn) {
        document.querySelectorAll('.slot-btn').forEach(b => b.classList.remove('selected'));
        btn.classList.add('selected');
    },

    setupBookingSlots: function () {
        const slots = document.querySelectorAll('.slot-btn');
        slots.forEach(slot => {
            slot.addEventListener('click', (e) => {
                slots.forEach(s => s.classList.remove('selected'));
                e.target.classList.add('selected');
            });
        });
    },

    confirmBooking: async function () {
        const user = this.currentUser;
        if (!user) {
            this.showToast("Please login first.", "error");
            return;
        }

        const dentistId = document.getElementById('selected-dentist-id').value;
        const serviceId = document.getElementById('booking-service').value;
        const dateInput = document.getElementById('booking-date').value;
        const selectedSlot = document.querySelector('.slot-btn.selected');

        if (!dentistId) {
            this.showToast("Please select a dentist first.", "warning");
            return;
        }
        if (!dateInput || !selectedSlot) {
            this.showToast("Please select a date and an available time slot.", "warning");
            return;
        }

        // Convert slot text (e.g., "10:00 AM") to 24h format
        const timeText = selectedSlot.textContent;
        let [time, ampm] = timeText.split(' ');
        let [hours, minutes] = time.split(':');
        hours = parseInt(hours);
        if (ampm === 'PM' && hours < 12) hours += 12;
        if (ampm === 'AM' && hours === 12) hours = 0;
        const startTime = `${hours.toString().padStart(2, '0')}:${minutes}:00`;

        this.showLoader("Securing your appointment...");

        try {
            const payload = {
                patient_id: user.id,
                dentist_id: dentistId,
                service_id: serviceId,
                appointment_date: dateInput,
                start_time: startTime
            };

            const response = await fetch('api/appointments/book.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });
            const result = await response.json();

            this.hideLoader();

            if (response.ok && result.status === 'success') {
                this.showToast("Appointment confirmed! See you then. 🎉", "success");

                // Fetch updated appointments immediately
                await this.refreshUserAppointments();

                setTimeout(() => {
                    this.switchPatientTab('my-appointments');
                }, 1000);
            } else {
                this.showToast(result.message || "Failed to book.", "error");
            }
        } catch (error) {
            console.error("Booking Error:", error);
            this.hideLoader();
            this.showToast("Connection lost. Please try again.", "error");
        }
    },

    refreshUserAppointments: async function () {
        if (!this.currentUser) return;
        try {
            // We just use the login endpoint logic to get full refreshed state or a dedicated endpoint
            // For now, let's just use the current appointments array and manually add if we wanted, 
            // but a fresh fetch is safer. We'll simulate a re-fetch since login.php does this.
            // Since we don't have a dedicated 'get_my_appointments.php', we can add one or 
            // just use the appointments/get.php if it's filtered (it's not).
            // Let's just update the local array for now to show visual change.
            const response = await fetch('api/appointments/get.php');
            const result = await response.json();
            if (response.ok && result.status === 'success') {
                // Filter for current user only
                this.currentAppointments = result.data.filter(a => a.patient_name === this.currentUser.name);
                this.renderPatientDashboard();
            }
        } catch (e) { }
    },

    // --- Admin Flow ---
    switchAdminTab: function (tabId, el) {
        document.querySelectorAll('.admin-tab').forEach(t => t.classList.remove('active'));
        document.getElementById(`admin-${tabId}`).classList.add('active');

        // Trigger real-time data fetch for specific tabs
        if (tabId === 'calendar') this.renderAdminCalendar();
        if (tabId === 'services') this.updateServiceList();
        if (tabId === 'dashboard') this.renderAdminDashboard();
        if (tabId === 'patients') this.updatePatientList();
        if (tabId === 'approvals') this.updateApprovalList();
        if (tabId === 'global-queue') this.renderGlobalQueue();
        if (tabId === 'settings') this.loadClinicSettings();
        if (tabId === 'dentists') this.updateDentistManageList();

        if (el) {
            document.querySelectorAll('.sidebar-menu li').forEach(li => li.classList.remove('active'));
            el.classList.add('active');
        } else {
            document.querySelectorAll('.sidebar-menu li').forEach(li => {
                li.classList.remove('active');
                if (li.getAttribute('onclick') && li.getAttribute('onclick').includes(tabId)) {
                    li.classList.add('active');
                }
            });
        }
    },

    sendOTP: function () {
        const phoneInput = document.querySelector('#phone-login-section input[type="tel"]');
        const phone = phoneInput ? phoneInput.value.trim() : '';

        if (!phone || phone.length < 7) {
            this.showToast("Please enter a valid phone number first.", "warning");
            if (phoneInput) phoneInput.focus();
            return;
        }

        this.triggerMockAction('Sending OTP code to ' + phone + '...', 'info');
        setTimeout(() => {
            const phoneRole = document.querySelector('input[name="phone-role"]:checked');
            if (phoneRole) {
                const loginRole = document.querySelector(`input[name="login-role"][value="${phoneRole.value}"]`);
                if (loginRole) loginRole.checked = true;
            }
            this.switchScreen('phone-otp-section');
        }, 500);
    },

    setupOTPAuth: function () {
        const otpInputs = document.querySelectorAll('.otp-input');
        otpInputs.forEach((input, index) => {
            input.addEventListener('input', (e) => {
                input.value = input.value.replace(/[^0-9]/g, '');
                if (input.value.length === 1 && index < otpInputs.length - 1) {
                    otpInputs[index + 1].focus();
                }
            });
            input.addEventListener('keydown', (e) => {
                if (e.key === 'Backspace' && input.value.length === 0 && index > 0) {
                    otpInputs[index - 1].focus();
                }
            });
        });

        document.addEventListener('keydown', (e) => {
            const otpScreen = document.getElementById('phone-otp-section');
            if (!otpScreen || !otpScreen.classList.contains('active')) return;
            if (!document.activeElement || !document.activeElement.classList.contains('otp-input')) {
                if (/^[0-9]$/.test(e.key)) {
                    e.preventDefault();
                    for (let input of otpInputs) {
                        if (!input.value) { input.focus(); input.value = e.key; input.dispatchEvent(new Event('input')); break; }
                    }
                }
                if (e.key === 'Backspace') {
                    e.preventDefault();
                    for (let i = otpInputs.length - 1; i >= 0; i--) {
                        if (otpInputs[i].value) { otpInputs[i].value = ''; otpInputs[i].focus(); break; }
                    }
                }
            }
        });
    },

    verifyOTP: function () {
        const otpInputs = document.querySelectorAll('.otp-input');
        let code = '';
        otpInputs.forEach(i => code += i.value);

        if (code.length < 6) {
            this.showToast("Please enter the complete 6-digit verification code.", "warning");
            for (let input of otpInputs) {
                if (!input.value) { input.focus(); break; }
            }
            return;
        }

        this.triggerMockAction('Verifying secure code...', 'info');
        setTimeout(() => {
            this.login();
        }, 500);
    },

    // --- Loading & Notification Actions ---
    triggerMockAction: function (actionName, actionType = 'info') {
        if (actionType === 'info') {
            this.showLoader("Processing detail block...");
            setTimeout(() => {
                this.hideLoader();
                this.showToast(actionName, "success");
            }, 500);
        } else {
            this.showToast(actionName, actionType);
        }
    },

    // --- Chatbot Logic ---
    toggleChat: function () {
        const chat = document.getElementById('chatbot-ui');
        chat.classList.toggle('hidden');
    },

    handleChatEnter: function (e) {
        if (e.key === 'Enter') {
            this.sendChatMessage();
        }
    },

    sendChatMessage: function () {
        const input = document.getElementById('chat-input');
        const text = input.value.trim();
        if (!text) return;

        this.appendChatMessage(text, 'user');
        input.value = '';

        setTimeout(() => {
            const lowerText = text.toLowerCase();
            let response = "I can help with that! Do you want me to check available slots?";

            if (lowerText.includes('book') || lowerText.includes('cleaning')) {
                response = "I see you want to book a cleaning. We have a slot tomorrow at 10:00 AM. Should I lock that in for you?";
            } else if (lowerText.includes('yes') || lowerText.includes('confirm')) {
                response = "Great! Your appointment is successfully booked. You will receive an SMS reminder. 🎉";
                this.showToast("AI automatically booked appointment", "success");
            } else if (lowerText.includes('cancel')) {
                response = "Please go to the 'My Appointments' tab to manage cancellations.";
            }

            this.appendChatMessage(response, 'bot');
        }, 800);
    },

    appendChatMessage: function (text, sender) {
        const chatBody = document.getElementById('chat-messages');
        const msgDiv = document.createElement('div');
        msgDiv.className = `msg ${sender}`;

        if (sender === 'bot') {
            msgDiv.innerHTML = `
                <div class="msg-icon"><i class='bx bx-bot'></i></div>
                <div class="msg-bubble"><p>${text}</p></div>
            `;
        } else {
            msgDiv.innerHTML = `<div class="msg-bubble"><p>${text}</p></div>`;
        }

        chatBody.appendChild(msgDiv);
        chatBody.scrollTop = chatBody.scrollHeight;
    },

    // --- Admin Calendar & Services Logic ---
    renderAdminCalendar: async function () {
        const calendarGrid = document.getElementById('admin-calendar-days');
        if (!calendarGrid) return;

        calendarGrid.innerHTML = '<div class="col-span-full py-5 text-center text-dim"><i class="bx bx-loader-alt bx-spin mr-1"></i> Syncing Calendar...</div>';

        try {
            // Isolation Rule: Only fetch current dentist's appointments if NOT Master Admin
            const dentistFilter = !this.currentUser.is_master ? `?dentist_id=${this.currentUser.id}` : '';
            const response = await fetch(`api/appointments/get.php${dentistFilter}`);
            const result = await response.json();
            const appointments = result.data || [];

            calendarGrid.innerHTML = '';

            const now = new Date();
            const currMonth = now.getMonth();
            const currYear = now.getFullYear();

            // Get first day of month and total days
            const firstDay = new Date(currYear, currMonth, 1).getDay(); // 0 (Sun) to 6 (Sat)
            const daysInMonth = new Date(currYear, currMonth + 1, 0).getDate();

            // Render empty slots for days of prev month
            for (let i = 0; i < firstDay; i++) {
                const emptyDay = document.createElement('div');
                emptyDay.className = 'cal-day empty';
                calendarGrid.appendChild(emptyDay);
            }

            for (let day = 1; day <= daysInMonth; day++) {
                const dayEl = document.createElement('div');
                dayEl.className = 'cal-day';

                // Highlight today
                if (day === now.getDate()) dayEl.classList.add('today', 'bg-primary-light');

                const dateKey = `${currYear}-${(currMonth + 1).toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}`;
                const dailyEvents = appointments.filter(a => a.appointment_date === dateKey);

                let eventsHtml = '';
                dailyEvents.forEach(evt => {
                    eventsHtml += `
                        <div class="cal-event blue soft-shadow-sm bg-white" style="font-size: 10px; padding: 2px; line-height: 1.2;">
                            <b>${this.formatTime(evt.start_time)}</b><br>${evt.patient_name}
                        </div>
                    `;
                });

                dayEl.innerHTML = `
                    <span class="day-num ${day === now.getDate() ? 'font-bold' : ''}">${day}</span>
                    <div class="cal-events-wrap mt-1">${eventsHtml}</div>
                `;
                calendarGrid.appendChild(dayEl);
            }
        } catch (e) {
            calendarGrid.innerHTML = '<p class="text-error p-2">Calendar sync failed.</p>';
        }
    },

    updateServiceList: async function () {
        const body = document.getElementById('admin-services-body');
        if (!body) return;

        body.innerHTML = '<tr><td colspan="4" class="text-center py-2">Loading services...</td></tr>';

        try {
            const response = await fetch('api/services/get.php');
            const result = await response.json();
            if (result.status === 'success') {
                let rows = '';
                result.data.forEach(s => {
                    rows += `
                    <tr class="table-row-hover">
                        <td class="pl-2 font-medium">
                            <div class="flex items-center gap-1">
                                <i class='bx bx-check-circle text-success opacity-70'></i>
                                ${s.name}
                            </div>
                        </td>
                        <td><span class="info-badge">${s.duration_minutes} mins</span></td>
                        <td class="font-bold">$${s.price}</td>
                        <td class="text-right pr-2">
                            <button class="btn-icon circle outline bg-white text-danger mr-1" onclick="app.showToast('Demo: Cannot delete core services', 'info')"><i class='bx bx-trash'></i></button>
                        </td>
                    </tr>`;
                });
                body.innerHTML = rows;
            }
        } catch (e) {
            body.innerHTML = '<tr><td colspan="4" class="text-center text-error py-2">Service sync failed.</td></tr>';
        }
    },

    openServiceModal: function () {
        document.getElementById('service-modal').classList.remove('hidden');
    },

    closeServiceModal: function () {
        document.getElementById('service-modal').classList.add('hidden');
    },

    addService: async function () {
        const name = document.getElementById('new-service-name').value;
        const duration = document.getElementById('new-service-duration').value;
        const price = document.getElementById('new-service-price').value;

        if (!name || !price || !duration) {
            this.showToast("Please fill all fields.", "warning");
            return;
        }

        this.showLoader("Publishing service...");
        try {
            const response = await fetch('api/services/add.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name, price, duration })
            });
            const result = await response.json();
            this.hideLoader();
            if (result.status === 'success') {
                this.showToast("New service is live!", "success");
                this.closeServiceModal();
                this.updateServiceList();
            } else {
                this.showToast(result.message, "error");
            }
        } catch (e) {
            this.hideLoader();
            this.showToast("System error.", "error");
        }
    },

    cancelAppointment: async function (appointmentId) {
        if (!confirm("Are you sure you want to cancel this appointment? This action cannot be undone.")) {
            return;
        }

        this.showLoader("Cancelling appointment...");
        try {
            const response = await fetch('api/appointments/cancel.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ appointment_id: appointmentId })
            });
            const result = await response.json();
            this.hideLoader();

            if (result.status === 'success') {
                this.showToast("Appointment cancelled successfully.", "success");
                // Refresh data
                await this.refreshUserAppointments();
            } else {
                this.showToast(result.message, "error");
            }
        } catch (e) {
            this.hideLoader();
            this.showToast("Connection error.", "error");
        }
    },

    updatePatientList: async function () {
        const body = document.getElementById('admin-patient-list-body');
        if (!body) return;

        body.innerHTML = '<tr><td colspan="4" class="text-center py-2"><i class="bx bx-loader-alt bx-spin mr-1"></i> Loading Directory...</td></tr>';

        try {
            const response = await fetch('api/patients/list.php');
            const result = await response.json();
            if (result.status === 'success') {
                let rows = '';
                result.data.forEach(p => {
                    const joined = new Date(p.created_at).toLocaleDateString();
                    rows += `
                    <tr class="table-row-hover">
                        <td class="pl-2 font-medium">${p.full_name}</td>
                        <td class="text-dim text-sm">${p.email}<br>${p.phone}</td>
                        <td class="text-dim text-sm">${joined}</td>
                        <td class="text-right pr-2">
                            <button class="btn-primary sm py-1" onclick="app.viewPatientDetails(${p.id})">
                                <i class='bx bx-show mr-1'></i> View Profile
                            </button>
                        </td>
                    </tr>`;
                });
                body.innerHTML = rows;
            }
        } catch (e) {
            body.innerHTML = '<tr><td colspan="4" class="text-center text-error py-2">Database error.</td></tr>';
        }
    },

    viewPatientDetails: async function (patientId) {
        this.showLoader("Retrieving patient file...");
        try {
            const response = await fetch(`api/patients/details.php?id=${patientId}`);
            const result = await response.json();
            this.hideLoader();

            if (result.status === 'success') {
                const p = result.patient;

                // Populate Modal Header
                document.getElementById('detail-patient-name').textContent = p.full_name;
                document.getElementById('detail-patient-email').textContent = p.email;

                // Populate Personal Info
                document.getElementById('detail-patient-phone').textContent = p.phone || '--';
                document.getElementById('detail-patient-dob').textContent = p.dob || 'Not Provided';
                document.getElementById('detail-patient-points').textContent = p.reward_points || '0';

                // Populate Medical Flags
                document.getElementById('detail-patient-allergies').textContent = p.allergies || 'None';
                document.getElementById('detail-patient-medications').textContent = p.medications || 'None';

                // Populate Appointments Table
                const apptBody = document.getElementById('detail-patient-appts');
                if (result.appointments.length > 0) {
                    let rows = '';
                    result.appointments.forEach(a => {
                        rows += `
                        <tr>
                            <td>${new Date(a.appointment_date).toLocaleDateString()}</td>
                            <td>${a.service_name}</td>
                            <td><span class="badge border-badge">${a.status}</span></td>
                        </tr>`;
                    });
                    apptBody.innerHTML = rows;
                } else {
                    apptBody.innerHTML = '<tr><td colspan="3" class="text-center py-2 text-dim italic">No recorded appointments.</td></tr>';
                }

                document.getElementById('patient-detail-modal').classList.remove('hidden');
            } else {
                this.showToast(result.message, "error");
            }
        } catch (e) {
            this.hideLoader();
            this.showToast("System crash while loading detail.", "error");
        }
    },

    closePatientModal: function () {
        document.getElementById('patient-detail-modal').classList.add('hidden');
    },

    loadClinicSettings: async function () {
        this.showLoader("Fetching clinic configuration...");
        try {
            const response = await fetch('api/settings/get.php');
            const result = await response.json();
            this.hideLoader();

            if (result.status === 'success') {
                const s = result.data;
                document.getElementById('set-clinic-open').value = s.clinic_open || '';
                document.getElementById('set-clinic-close').value = s.clinic_close || '';
                document.getElementById('set-break-start').value = s.break_start || '';
                document.getElementById('set-break-end').value = s.break_end || '';
                this.showToast("Configuration loaded.", "info");
            }
        } catch (e) {
            this.hideLoader();
            this.showToast("Failed to load settings.", "error");
        }
    },

    saveClinicSettings: async function () {
        const payload = {
            clinic_open: document.getElementById('set-clinic-open').value,
            clinic_close: document.getElementById('set-clinic-close').value,
            break_start: document.getElementById('set-break-start').value,
            break_end: document.getElementById('set-break-end').value
        };

        this.showLoader("Saving clinic hours...");
        try {
            const response = await fetch('api/settings/update.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });
            const result = await response.json();
            this.hideLoader();

            if (result.status === 'success') {
                this.showToast("Clinic configuration updated!", "success");
            } else {
                this.showToast(result.message, "error");
            }
        } catch (e) {
            this.hideLoader();
            this.showToast("System error while saving.", "error");
        }
    },

    updateApprovalList: async function () {
        const body = document.getElementById('admin-approval-list');
        if (!body) return;

        body.innerHTML = '<tr><td colspan="4" class="text-center py-2"><i class="bx bx-loader-alt bx-spin mr-1"></i> Checking registrations...</td></tr>';

        try {
            const response = await fetch('api/admin/pending_list.php');
            const result = await response.json();
            if (result.status === 'success') {
                if (result.data.length === 0) {
                    body.innerHTML = '<tr><td colspan="4" class="text-center py-2 text-dim italic">No pending requests at the moment.</td></tr>';
                    return;
                }

                let html = '';
                result.data.forEach(u => {
                    html += `
                    <tr>
                        <td class="font-bold">${u.full_name}<br><span class="text-xs text-dim">${u.email}</span></td>
                        <td><span class="badge border-badge uppercase">${u.role}</span></td>
                        <td class="text-sm">${u.phone}</td>
                        <td class="text-right">
                            <button class="btn-icon circle bg-success-light text-success mr-1" onclick="app.processApproval(${u.id}, 'approve')" title="Approve">
                                <i class='bx bx-check'></i>
                            </button>
                            <button class="btn-icon circle bg-muted text-danger" onclick="app.processApproval(${u.id}, 'reject')" title="Reject">
                                <i class='bx bx-trash'></i>
                            </button>
                        </td>
                    </tr>`;
                });
                body.innerHTML = html;
            }
        } catch (e) {
            body.innerHTML = '<tr><td colspan="4" class="text-center text-error py-2">Approval gateway error.</td></tr>';
        }
    },

    processApproval: async function (userId, action) {
        if (!confirm(`Are you sure you want to ${action} this potential staff member?`)) return;

        this.showLoader(`${action === 'approve' ? 'Verifying' : 'Removing'} user...`);
        try {
            const response = await fetch('api/admin/approve_user.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ user_id: userId, action: action })
            });
            const result = await response.json();
            this.hideLoader();

            if (result.status === 'success') {
                this.showToast(result.message, "success");
                this.updateApprovalList();
            } else {
                this.showToast(result.message, "error");
            }
        } catch (e) {
            this.hideLoader();
            this.showToast("Critical error during approval process.", "error");
        }
    },

    renderGlobalQueue: async function () {
        const body = document.getElementById('global-queue-body');
        if (!body) return;

        body.innerHTML = '<tr><td colspan="5" class="text-center py-2"><i class="bx bx-loader-alt bx-spin mr-1"></i> Syncing Clinic Queue...</td></tr>';

        try {
            const response = await fetch('api/appointments/get.php');
            const result = await response.json();

            if (result.status === 'success') {
                this.globalQueueCache = result.data; // Store in cache for searching
                this.filterGlobalQueue(''); // Trigger initial render
            }
        } catch (e) {
            body.innerHTML = '<tr><td colspan="5" class="text-center text-error py-2">Queue connection error.</td></tr>';
        }
    },

    filterGlobalQueue: function (query = '') {
        const body = document.getElementById('global-queue-body');
        if (!body) return;

        const filtered = this.globalQueueCache.filter(a => {
            const q = query.toLowerCase();
            return a.patient_name.toLowerCase().includes(q) ||
                a.dentist_name.toLowerCase().includes(q) ||
                a.service_name.toLowerCase().includes(q) ||
                a.appointment_date.includes(q);
        });

        if (filtered.length === 0) {
            body.innerHTML = `<tr><td colspan="5" class="text-center py-2 text-dim italic">No matching records found for "${query}".</td></tr>`;
            return;
        }

        let html = '';
        filtered.forEach(a => {
            const statusClass = a.status === 'done' ? 'bg-success-light text-success' :
                (a.status === 'processing' ? 'bg-warning-light text-warning' : 'bg-muted text-dim');

            html += `
            <tr>
                <td class="font-medium">${a.appointment_date}<br><span class="text-xs text-dim">${this.formatTime(a.start_time)}</span></td>
                <td class="text-sm">${a.patient_name}</td>
                <td class="text-sm font-bold text-primary">${a.service_name}</td>
                <td>
                    <div class="flex items-center gap-1">
                        <div class="avatar-tiny bg-primary-light text-primary">${a.dentist_name[0]}</div>
                        <span class="text-xs font-bold">${a.dentist_name}</span>
                    </div>
                </td>
                <td><span class="badge ${statusClass} uppercase text-xs">${a.status}</span></td>
                <td class="text-right">
                    <div class="flex items-center justify-end gap-1">
                         <button class="btn-icon circle outline sm" onclick="app.viewPatientDetails(${a.patient_id})" title="View Profile"><i class='bx bx-show'></i></button>
                         
                         ${a.status === 'pending' ? `
                            <button class="btn-icon circle bg-success-light text-success sm" onclick="app.updateAppointmentStatus(${a.id}, 'upcoming')" title="Approve Request">
                                <i class='bx bx-check'></i>
                            </button>
                            <button class="btn-icon circle bg-muted text-danger sm" onclick="app.updateAppointmentStatus(${a.id}, 'cancelled')" title="Decline Request">
                                <i class='bx bx-x'></i>
                            </button>
                         ` : `
                            <button class="btn-icon circle text-dim" onclick="app.updateAppointmentStatus(${a.id}, 'pending')" title="Mark as Pending"><i class='bx bx-undo'></i></button>
                            <button class="btn-icon circle text-warning" onclick="app.updateAppointmentStatus(${a.id}, 'processing')" title="Processing"><i class='bx bx-play'></i></button>
                            <button class="btn-icon circle text-success" onclick="app.updateAppointmentStatus(${a.id}, 'done')" title="Done"><i class='bx bx-check-double'></i></button>
                         `}
                    </div>
                </td>
            </tr>`;
        });
        body.innerHTML = html;
    },

    updateAppointmentStatus: async function (id, newStatus) {
        this.showLoader(`Marking as ${newStatus}...`);
        try {
            const response = await fetch('api/appointments/update_status.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ appointment_id: id, status: newStatus })
            });
            const result = await response.json();
            this.hideLoader();

            if (result.status === 'success') {
                this.showToast(result.message, "success");
                // Refresh both current views
                if (document.getElementById('admin-dashboard').classList.contains('active')) this.renderAdminDashboard();
                if (document.getElementById('admin-global-queue').classList.contains('active')) this.renderGlobalQueue();
            } else {
                this.showToast(result.message, "error");
            }
        } catch (e) {
            this.hideLoader();
            this.showToast("Failed to update status.", "error");
        }
    },

    generateGlobalReport: function () {
        if (this.globalQueueCache.length === 0) {
            this.showToast("No data to export.", "warning");
            return;
        }

        // Generate CSV header
        let csvContent = "data:text/csv;charset=utf-8,";
        csvContent += "Date,Time,Patient,Service,Dentist,Status\n";

        // Add rows
        this.globalQueueCache.forEach(a => {
            const row = `${a.appointment_date},${a.start_time},${a.patient_name},${a.service_name},${a.dentist_name},${a.status}`;
            csvContent += row + "\n";
        });

        // Download link
        const encodedUri = encodeURI(csvContent);
        const link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", `DentAssist_Clinic_Report_${new Date().toISOString().split('T')[0]}.csv`);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);

        this.showToast("Report downloaded successfully!", "success");
    },

    // --- Dentist-First Booking Logic ---
    loadDentists: async function () {
        const dentistList = document.getElementById('dentist-list');
        if (!dentistList) return;

        try {
            const response = await fetch('api/dentists/list.php');
            const result = await response.json();
            if (result.status === 'success') {
                let html = '';
                result.data.forEach(d => {
                    const initials = d.full_name.split(' ').map(n => n[0]).join('');
                    html += `
                        <div class="dentist-card" onclick="app.selectDentist(this, '${d.id}', '${d.full_name}')">
                            <div class="online-badge">Online</div>
                            <div class="avatar-large flex-center bg-muted text-dim font-bold mx-auto mb-1 border-dashed">
                                ${initials}
                            </div>
                            <h4 class="font-bold text-sm">${d.full_name}</h4>
                            <p class="text-xs text-dim">Specialist</p>
                        </div>
                    `;
                });
                dentistList.innerHTML = html;
            }
        } catch (e) {
            dentistList.innerHTML = '<div class="text-error italic">Could not load experts.</div>';
        }
    },

    selectDentist: function (el, id, name) {
        // Update UI selection
        document.querySelectorAll('.dentist-card').forEach(c => c.classList.remove('selected'));
        el.classList.add('selected');

        // Store value
        document.getElementById('selected-dentist-id').value = id;

        // Show badge
        const badge = document.getElementById('dentist-badge-placeholder');
        badge.classList.remove('hidden');
        document.getElementById('selected-dentist-name-badge').textContent = name;

        // Auto-check availability if date is already set
        const dateInput = document.getElementById('booking-date').value;
        if (dateInput) {
            this.checkAvailability();
        }
    },

    // --- Master Admin Professional Management ---
    updateDentistManageList: async function () {
        const body = document.getElementById('admin-dentist-manage-list');
        if (!body) return;

        body.innerHTML = '<tr><td colspan="5" class="text-center py-2"><i class="bx bx-loader-alt bx-spin mr-1"></i> Scanning staff directory...</td></tr>';

        try {
            // Re-use the list API (now filtered by active in previous task, but let's check ALL or just active/suspended)
            // Actually, Master Admin should see ACTIVE + SUSPENDED, but not pending (that's in Approvals TAB)
            const response = await fetch('api/dentists/list.php'); // Note: I might need a new API to show Suspended ones too, but let's stick to active for now
            const result = await response.json();

            if (result.status === 'success') {
                if (result.data.length === 0) {
                    body.innerHTML = '<tr><td colspan="5" class="text-center py-2 text-dim italic">No active professionals found.</td></tr>';
                    return;
                }

                let html = '';
                result.data.forEach(d => {
                    const statusBadge = d.id === 1 ? '<span class="badge badge-active">Protected</span>' : '<span class="badge border-badge">Verified</span>';
                    const removeBtn = d.id === 1 ? '' : `
                        <button class="btn-icon circle outline text-danger" onclick="app.removeDentist(${d.id}, '${d.full_name}')" title="Remove Professional">
                            <i class='bx bx-user-minus'></i>
                        </button>
                    `;

                    html += `
                    <tr>
                        <td class="font-bold">${d.full_name}</td>
                        <td><span class="badge bg-muted uppercase text-xs">${d.role}</span></td>
                        <td class="text-sm text-dim">${d.email}</td>
                        <td>${statusBadge}</td>
                        <td class="text-right">
                            ${removeBtn}
                        </td>
                    </tr>`;
                });
                body.innerHTML = html;
            }
        } catch (e) {
            body.innerHTML = '<tr><td colspan="5" class="text-center text-error py-2">Staff lookup failed.</td></tr>';
        }
    },

    removeDentist: async function (userId, name) {
        if (!confirm(`CAUTION: You are about to remove ${name} from the system. This will revoke their access immediately. Proceed?`)) return;

        this.showLoader("Removing credentials...");
        try {
            const response = await fetch('api/admin/delete_user.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ user_id: userId, action: 'delete' })
            });
            const result = await response.json();
            this.hideLoader();

            if (result.status === 'success') {
                this.showToast(result.message, "success");
                this.updateDentistManageList();
            } else {
                this.showToast(result.message, "error");
            }
        } catch (e) {
            this.hideLoader();
            this.showToast("Critical failure during removal.", "error");
        }
    }
};

// Initialize App
document.addEventListener('DOMContentLoaded', () => {
    app.init();
});
